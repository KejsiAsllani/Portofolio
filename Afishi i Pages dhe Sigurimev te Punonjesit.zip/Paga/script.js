
const grossInput = document.querySelector('.gross');
const turnNet = document.querySelector('.g-net'); 
const button = document.querySelector('.gross-net');
const button2=document.querySelector('.net-gross');
const netInput=document.querySelector('.net');
const turnGross=document.querySelector('.n-gross');
const button4=document.querySelector('.insurance-button .button');
const insuranceArea=document.querySelector('.insurance-area');



//function of second and third part to convert from gross salary to net salary

function calculateInsurance(grossSalary) {
    const socialInsurance = grossSalary * 0.095; 
    const healthyInsurance = grossSalary * 0.017; 

    const taxableIncome = grossSalary - (socialInsurance + healthyInsurance);

    let taxes = 0;

    if (taxableIncome <= 20000) {
        taxes = taxableIncome; 
    } else if (taxableIncome >50000 && taxableIncome<= 200000) { 
        taxes = taxableIncome * 0.13;
    } else {
        taxes = taxableIncome * 0.23;
    }

    return { socialInsurance, healthyInsurance, taxes };
}

function calculateNet() {
    const grossSalary = parseFloat(grossInput.value);

    const { socialInsurance, healthyInsurance, taxes } = calculateInsurance(grossSalary);

    const netSalary = grossSalary - (socialInsurance + healthyInsurance + taxes);

    turnNet.value = netSalary.toFixed(2);


    //solutin for textArea , third part

    const details=`Social Insurance:${socialInsurance.toFixed(2)}\nHealthy Insurance:${healthyInsurance.toFixed(2)}\nTaxes:${taxes.toFixed(2)}`;

    button4.addEventListener('click',function(e){
        e.target.classList.remove('fa-toggle-off' );
            e.target.classList.add('fa-toggle-on');
            insuranceArea.value=details;
           
    });

};

button.addEventListener('click', calculateNet);

//function of second part to convert the salary fron net salary to gross salary

function calculateGross(){

    const netSalary= parseFloat(netInput.value);
    let taxesPercentages=0;
 
    if (netSalary <= 20000) {
        taxesPercentages = 0; 
    } else if (netSalary>50000 && netSalary <= 200000) { 
        taxesPercentages = 0.13;
    } else {
        taxesPercentages = 0.23;
    }

     const grossSalary=netSalary /(1- 0.129 - taxesPercentages);
     
     turnGross.value=grossSalary.toFixed(2);

     const { socialInsurance, healthyInsurance, taxes } = calculateInsurance(grossSalary);


 const details=`Social Insurance:${socialInsurance.toFixed(2)}\nHealthy Insurance:${healthyInsurance.toFixed(2)}\nTaxes:${taxes.toFixed(2)}`;

     button4.addEventListener('click',function(e){
        e.target.classList.remove('fa-toggle-off' );
            e.target.classList.add('fa-toggle-on');
            insuranceArea.value=details;
    });

};
button2.addEventListener('click', calculateGross);


//the function for the first part, to find the gross salary if we have working day and salary per day

const nameInput=document.querySelector('.name');
const surnameInput=document.querySelector('.surname');
const dayInput=document.querySelector('.day');
const salaryInput=document.querySelector('.salary');
const button3=document.querySelector('.identity-button')

function grossFuncion(){
    const dayValue=parseFloat(dayInput.value);
    const salaryValue=parseFloat(salaryInput.value);

    const allGrossSalary=dayValue*salaryValue;
  alert(`${nameInput.value} ${surnameInput.value} you have a gross salary:${allGrossSalary} leke`);
};

button3.addEventListener('click', grossFuncion);




