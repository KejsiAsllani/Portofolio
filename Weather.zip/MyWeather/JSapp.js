const cityForm=document.querySelector('form');
const card=document.querySelector('.card');
const time=document.querySelector('img.time');
const icon=document.querySelector('.img.w-c');
const details=document.querySelector('.information');
const cityname=document.querySelector('.item1 h1');

const updatePage=(data)=>{
    console.log(data);
    

    const{cityDetail,weatherDetail}=data;
    console.log('Weather Icon:', weatherDetail.WeatherIcon);
    cityname.innerHTML=
    `<div class="item1">
            <h1>${cityDetail.EnglishName}</h1>
           
       </div>`;

    details.innerHTML=
    `
    
            <div class="information">
                <h2>Location:</h2>
                <span>${cityDetail.Country.LocalizedName}</span>
                <h2>Temperature:</h2>
             <span>${weatherDetail.Temperature.Metric.Value}&deg;</span>
                
                <h2>Weather condition:</h2>
                <span>${weatherDetail.WeatherText}</span>
                
            </div>
       `;

        if(card.classList.contains('d-none')){
            card.classList.remove('d-none');
        };

        let timeSource= weatherDetail.IsDayTime?'img/day.svg':'img/night.svg';
        time.setAttribute('src',timeSource);

        //const iconSourse=`img/icons/${weatherDetail.WeatherIcon}.svg`;
        //icon.setAttribute('src',iconSourse);
      

};


const updateCity=async(city)=>{
    const cityDetail=await getCity(city);
    const  weatherDetail=await getWeather(cityDetail.Key);
   // const  satelitDetail=await getSatelit(cityDetail.key);
return{cityDetail,weatherDetail};

};
cityForm.addEventListener('submit',e => {

    e.preventDefault();
    const city=cityForm.city.value.trim();
    cityForm.reset();

    updateCity(city)
              .then(data=> updatePage(data))
              .catch(err=>console.log(err));
});